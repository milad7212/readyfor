"use strict";
exports.id = 54;
exports.ids = [54];
exports.modules = {

/***/ 3054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-icons/hi"
var hi_ = __webpack_require__(1111);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: external "react-icons/cg"
var cg_ = __webpack_require__(7865);
// EXTERNAL MODULE: external "react-icons/go"
var go_ = __webpack_require__(5856);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/layout/Sidebar.jsx



const isNotActiveStyle = "flex items-center px-5 gap-3 text-gray-500 hover:text-black transition-all duration-200 ease-in-out capitalize";
const isActiveStyle = "flex items-center px-5 gap-3 font-extrabold border-l-2 border-black  transition-all duration-200 ease-in-out capitalize";
const categories = [
    {
        name: "آزمون نظام مهندسی"
    },
    {
        name: "پروفایل"
    },
    {
        name: "Photography"
    },
    {
        name: "Gaming"
    },
    {
        name: "Coding"
    }
];
function Sidebar({ closeToggle  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex flex-col justify-between bg-gray-400 h-full ",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex px-5 gap-2 my-6 pt-1 w-[190px] items-center"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col gap-5",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: isActiveStyle,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(hi_.HiHome, {
                                    fontSize: 24
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "خانه"
                                })
                            ]
                        }),
                        categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "px-5",
                                children: category.name
                            }, category.name))
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const layout_Sidebar = (Sidebar);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./components/layout/Layout.jsx










function Layout({ children  }) {
    const [toggleSidebar, setToggleSidebar] = (0,external_react_.useState)(false);
    const [toggleSidebarDes, setToggleSidebarDes] = (0,external_react_.useState)(false);
    const [searchTerm, setSearchTerm] = (0,external_react_.useState)("");
    const scrollRef = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        scrollRef.current.scrollTo(0, 0);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "پرنده شب"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "initial-scale=1.0, width=device-width"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "shadow-header flex border-b border-gray-500 bg-ciBackBeauty ",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex w-full flex-row items-center justify-between p-2 shadow-md",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(go_.GoHome, {
                                            fontSize: 30,
                                            className: "mr-4 cursor-pointer text-gray-200"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/welcome",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsHandThumbsUpFill, {
                                            fontSize: 30,
                                            className: "mr-4 cursor-pointer text-gray-200"
                                        })
                                    })
                                ]
                            }),
                            toggleSidebar && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "animate-slide-in fixed z-10 h-screen w-4/5 overflow-y-auto bg-white shadow-md",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute flex w-full items-center justify-end p-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillCloseCircle, {
                                            fontSize: 30,
                                            className: "cursor-pointer",
                                            onClick: ()=>setToggleSidebar(false)
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(layout_Sidebar, {
                                        closeToggle: setToggleSidebar
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex h-screen flex-col bg-gray-50 md:flex-row ",
                        children: [
                            toggleSidebarDes && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " h-screen ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(layout_Sidebar, {})
                            }),
                            toggleSidebar && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "animate-slide-in fixed z-10 h-screen w-4/5 overflow-y-auto bg-white shadow-md",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "absolute flex w-full items-center justify-end p-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillCloseCircle, {
                                            fontSize: 30,
                                            className: "cursor-pointer",
                                            onClick: ()=>setToggleSidebar(false)
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(layout_Sidebar, {
                                        closeToggle: setToggleSidebar
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "min-h-screen flex-1 pb-2",
                                ref: scrollRef,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-gray-50",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "h-full",
                                        children: children
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const layout_Layout = (Layout);


/***/ })

};
;