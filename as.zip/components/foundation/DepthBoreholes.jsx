import React from 'react'

function DepthBoreholes() {
  return (
    <div className=""></div>
  )
}

export default DepthBoreholes