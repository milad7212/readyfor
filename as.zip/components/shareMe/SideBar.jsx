import React from 'react'

function SideBar() {
  return (
    <div>SideBar</div>
  )
}

export default SideBar