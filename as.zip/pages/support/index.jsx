import React from 'react'

function SupportPage() {
  return (
    <div className=" min-h-screen bg-ciBackBeauty p-3 "></div>
  )
}

export default SupportPage